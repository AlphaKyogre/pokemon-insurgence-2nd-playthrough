+---------------======<<{()}>>======---------------+
|\				                  /|
[>]  SERVANT'S BRIGHTER UI - POK�MON INSURGENCE  [<]  
|/     					          \|
+--------------------===<<>>===--------------------+

    Installation
-=-=-=-=-=-=-=-=-=-=-

1. Make a backup of your Pictures folder (under Graphics in the core Insurgence files),
   in case you're not a fan of the new look.
2. Unzip this archive.
3. Drop all the .png image files into your Pictures folder.  For me, the file path was
   Pokemon Insurgence 1.2.3 Core -> Graphics -> Pictures
4. When prompted, select "Replace All."
5. Done!  When you boot up the game, your selection boxes should be brighter.


Credit for all the textures goes to the makers of Pok�mon Insurgence.
All I did was modify them a little.

-=-=-=-=-=-=-=-=-=-=-
To Jesus Christ my Savior and my Lord be the glory!

If you want to know more about who God is, and about his
Son, Jesus Christ, who lived the perfect and good life 
that we couldn't live and died the death we all deserved
to pay for our sins, then rose from the dead according to
hundreds of witnesses, then I'd love to tell you about Him!

By all means, shoot me an email at sunstepstorm@gmail.com.  There
is nothing more important--or wonderful--than this good news!

"For all have sinned and fall short of the glory of God,
and all are justified freely by his grace through the
redemption that came by Christ Jesus.  God presented Christ
as a sacrifice of atonement, through the shedding of his
blood--to be received by faith."
-- Romans 3:23-25a (NIV)

"And you were dead in the
trespasses and sins in which
you once walked...
But God, being rich in mercy,
because of the great love with
which he loved us, even when we
were dead in our trespasses,
made us alive together with Christ--
by grace you have been saved..."
-- Ephesians 2:4-5 (ESV)

There is a God-shaped hole in all of our hearts, and no matter
how hard we try to fill it, only He can give us real peace and
satisfaction.  Games are a lot of fun, but they can't give us
eternal life and real meaning the way Jesus can.

Without the blood of Jesus to pay for our sins, we're all under
God's righteous judgment and bound for the hell we deserve for our
treason against a perfect God, but if we confess our sins and ask for
forgiveness, believing that Jesus Christ is God (as he said he is), 
then we're free from our sins and no longer condemned!  Instead, we're
welcomed into God's family as sons and daughters, and after death, we'll spend
all eternity with him in awesome joy and a satisfaction that makes
everything we've ever known look like nothing in comparison!

-- Servant of the King (Nathan)
